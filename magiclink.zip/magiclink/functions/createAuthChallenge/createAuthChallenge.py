import json
import boto3
import os
import time
import hmac
import hashlib
import base64
import uuid
from botocore.exceptions import ClientError

# Initialize SES client
ses = boto3.client("ses")  # Replace "your-region" with your AWS region

# Environment variables
SES_FROM_ADDRESS = os.environ.get("SES_FROM_ADDRESS","noreply@example.com")  # e.g., "noreply@example.com"
BASE_URL = os.environ.get("BASE_URL","https://your-domain.com/verify")  # e.g., "https://your-domain.com/verify"
TIMEOUT_MINS = int(os.environ.get("TIMEOUT_MINS", 15))  # Default timeout 15 mins
SECRET_KEY = os.environ.get("SECRET_KEY","e4f89d8231c9b4411c02c3f8a9987e5125d4c8f9e6b5a2e37f8c4e59f3b2a456")  # Secret key for signing the token

def get_response(status_code, message='Success', data=None):
    """Format API Gateway response."""
    return {
        "isBase64Encoded": False,
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST",
            "Access-Control-Allow-Headers": "*",
        },
        "body": json.dumps({
            "message": message,
            "data": data
        }),
    }

def generate_magic_link(email):
    """Generate a signed magic link with an expiration time."""
    expiration_time = int(time.time()) + (TIMEOUT_MINS * 60)  # Current time + timeout in seconds
    unique_id = str(uuid.uuid4())  # Generate a unique token
    token_data = f"{email}|{unique_id}|{expiration_time}"
    
    # Sign the token with HMAC-SHA256
    signature = hmac.new(
        bytes(SECRET_KEY, "utf-8"),
        token_data.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    
    # Create the full token
    token = f"{token_data}|{signature}"
    
    # Encode token in Base64 for URL safety
    token_encoded = base64.urlsafe_b64encode(token.encode()).decode()
    
    # Construct the magic link
    magic_link = f"{BASE_URL}?token={token_encoded}"
    return magic_link,token_encoded,expiration_time


def send_email(email_address, magic_link):
    """Send the magic link via email using SES v1 parameters."""
    try:
        response = ses.send_email(
            Source=SES_FROM_ADDRESS,  # Sender's email address
            Destination={
                "ToAddresses": [email_address]
            },
            Message={
                "Subject": {
                    "Data": "Your one-time sign in link",
                    "Charset": "UTF-8"
                },
                "Body": {
                    "Html": {
                        "Data": f"""<html><body>
                                    <p>This is your one-time sign in link (it will expire in {TIMEOUT_MINS} mins):</p>
                                    <a href="{magic_link}">{magic_link}</a>
                                    </body></html>""",
                        "Charset": "UTF-8"
                    },
                    "Text": {
                        "Data": f"Your one-time sign in link (it will expire in {TIMEOUT_MINS} mins): {magic_link}",
                        "Charset": "UTF-8"
                    }
                }
            }
        )
        print(f"Email sent successfully. Response: {response}")
    except Exception as e:
        print(f"Failed to send email to {email_address}. Error: {str(e)}")
        raise


def lambda_handler(event, context):
    """Handle the Lambda function event."""
    try:
        # Parse input
        print(event)
        email = event['request']['userAttributes']['email']
        
        if not email:
            return get_response(400, "Email address is required")
        
        # Generate the magic link
        magic_link, token, expiration_time = generate_magic_link(email)
        print("magic_link\n",magic_link)
        # Send the email
        send_email(email, magic_link)
        event['response']['publicChallengeParameters'] = {
            'email': email,
            'token':token
        }
        event['response']['privateChallengeParameters'] = {
            'token': token,
            'expiration_time':expiration_time  # Use the same token here
            
        }
     
        # Optionally, set challenge metadata for additional context
        event['response']['challengeMetadata'] = "MAGIC_LINK_SENT"

        return event 
        # return get_response(200, "Magic link sent successfully")
    
    except ClientError as e:
        print(f"Client error: {str(e)}")
        return get_response(500, "Failed to send magic link", {"error": str(e)})
    
    except Exception as e:
        print(f"Unhandled error: {str(e)}")
        return get_response(500, "An error occurred", {"error": str(e)})

