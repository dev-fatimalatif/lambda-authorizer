import json
from datetime import datetime
import base64

def lambda_handler(event, context):
    print(event)
    try:
        email = event['request']['userAttributes']['email']
        expected_token = event['request']['privateChallengeParameters']['token']
        challenge_answer = event['request']['challengeAnswer']

        print("Email from userAttributes:", email)
        print("Expected Token (from privateChallengeParameters):", expected_token)
        print("Challenge Answer:", challenge_answer)

        # Check if the challenge answer matches the expected token
        if challenge_answer != expected_token:
            print("Answer doesn't match current challenge token")
            event['response']['answerCorrect'] = False
            return event

        # Decode the Base64-encoded challenge answer
        try:
            decoded_answer = base64.urlsafe_b64decode(challenge_answer).decode('utf-8')
            print("Decoded Challenge Answer:", decoded_answer)
        except Exception as e:
            print("Error decoding challengeAnswer:", e)
            event['response']['answerCorrect'] = False
            return event

        # Split the decoded answer into components (assuming pipe-separated values)
        try:
            email_from_token, uuid, expiration, signature = decoded_answer.split('|')
            print("Email from Token:", email_from_token)
            print("UUID from Token:", uuid)
            print("Expiration from Token:", expiration)
            print("Signature from Token:", signature)
        except ValueError as e:
            print("Error splitting decoded answer:", e)
            event['response']['answerCorrect'] = False
            return event

        # Validate expiration
        current_time = int(datetime.utcnow().timestamp())
        print("Current Time (UTC):", current_time)
        print("Token Expiration Time:", expiration)

        is_expired = current_time > int(expiration)
        print("Is Token Expired:", is_expired)

        # Validate email and expiration
        if email_from_token == email and not is_expired:
            event['response']['answerCorrect'] = True
        else:
            print("Email doesn't match or token is expired")
            event['response']['answerCorrect'] = False

    except Exception as e:
        print("Unhandled exception:", e)
        event['response']['answerCorrect'] = False

    return event
