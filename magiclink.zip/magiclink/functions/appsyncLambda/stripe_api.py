import stripe
import os
from config import * 
stripe.api_key = os.environ["STRIPEAPIKEY"]




def create_checkout_session(plan_product_data, user_email, return_url):
    """
    Creates a Stripe Checkout session and returns the client secret.
    """
    session = stripe.checkout.Session.create(
        ui_mode="embedded",
        line_items=[
            plan_product_data
        ],
        allow_promotion_codes=True,
        mode="payment",
        customer_email=user_email,
        return_url=return_url
    )
    return session.client_secret

def get_session_status(session_id):
    """
    Retrieves the status of a Stripe Checkout session.
    """
    session = stripe.checkout.Session.retrieve(session_id)
    return session.payment_status

def create_gift_checkout_session(token_data,return_url):
    total_amount = 0
    for token in token_data:
        if token["isRedeemed"]:
            return {"message":"bad request","statusCode":400}
        plan = token["photoShootPlan"]
        amount = PLANS[plan]["price_data"]["unit_amount"]
        total_amount = total_amount+amount
        email = token["senderEmail"]
    checkout_plan ={
        "price_data": {
            "currency": "usd",
            "product_data": {
                "name": "Gift plan",
                "description": "This plan is for gift checkout",
            },
            "unit_amount": total_amount,  # $59 in cents
        },
        "quantity": 1,
    }

    return create_checkout_session(checkout_plan,email,return_url)