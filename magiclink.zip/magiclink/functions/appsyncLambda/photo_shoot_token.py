

import boto3
import uuid
import os
import logging
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ["DYNAMO_DB_TABLE_HEADSHOT_TOKENS"])


def create_gift_token(gift_plan, gift_recipients, sender_name, sender_email,gift_image):

    # Initialize a list to hold the generated gift URLs
    gift_tokens = []

    try:
        for recipient in gift_recipients:
            token = str(uuid.uuid4())
            timestamp = datetime.utcnow().isoformat() + 'Z'  # ISO 8601 format with 'Z' for UTC

            # Create the item with recipient-specific data
            item = {
                'tokenId': token,
                'photoShootPlan': gift_plan,
                'senderName': sender_name,
                'senderEmail': sender_email,
                'recipientName': recipient['recipientName'],
                'recipientEmail': recipient['recipientEmail'],
                'personalMessage': recipient['recipientPersonalMessage'],
                'isRedeemed': False,
                'giftStatus':"CREATED",
                'giftImage':gift_image,
                'createdAt': timestamp  # Add timestamp
            }

            # Insert item into DynamoDB
            table.put_item(Item=item)

            # Append the generated gift URL to the list
            gift_tokens.append(token)

        return {
            "giftToken": gift_tokens,
            "message": "URLs generated successfully",
            "statusCode": 200
        }
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {
            "message": "bad request",
            "statusCode": 400
        }

def create_token(user_id, photo_shoot_plan):
    # Generate a unique tokenId
    token = str(uuid.uuid4())
    
    # Add current timestamp
    timestamp = datetime.utcnow().isoformat() + 'Z'  # ISO 8601 format with 'Z' for UTC
    
    item = {
        'tokenId': token,
        'photoShootPlan': photo_shoot_plan,
        'createdBy': user_id,
        'isRedeemed': False,
        'createdAt': timestamp  # Add timestamp
    }
    
    try:
        # Insert item into DynamoDB
        table.put_item(Item=item)
        return {
            "giftUrl": f"{os.environ['HEAD_SHOT_DOMAIN']}/?photoShootToken={token}",
            "message": "URL generated successfully",
            "statusCode": 200
        }
    except Exception as e:
        logging.error(e, exc_info=True)
        return {
            "message": "Bad request",
            "statusCode": 400
        }

def get_gift_tokens(token_ids):
    try:
        # Initialize the list to store tokens
        tokens_data = []

        # Process each token ID in the list
        for token_id in token_ids:
            # Fetch the item from DynamoDB
            response = table.get_item(Key={'tokenId': token_id})

            token = response.get('Item',[])
            
            # Add token data to the list
            tokens_data.append(token)

        # Return all retrieved data
        return tokens_data
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return []



def get_token(token_id):
    try:
        # Fetch the item from DynamoDB
        response = table.get_item(Key={'tokenId': token_id})
        
        # Check if the item exists
        if 'Item' not in response:
            return {"message": "Token not found", "statusCode": 404}
        
        token = response['Item']
        
        # Check if the token is already redeemed
        if token['isRedeemed']:
            return {"message": "Token has already been redeemed", "statusCode": 401}
        
        # Add photoShootPlan to the response
        return {
            "data": {
                "tokenId": token['tokenId'],
                "photoShootPlan": token['photoShootPlan'],
                "isRedeemed": token['isRedeemed']
            },
            "message": "Token retrieved successfully",
            "statusCode": 200
        }
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "Bad request", "statusCode": 400}


def update_token(token_id):
    try:
        # Update the isRedeemed field to True
        response = table.update_item(
            Key={'tokenId': token_id},
            UpdateExpression="SET isRedeemed = :true",
            ExpressionAttributeValues={':true': True},
            ConditionExpression="attribute_exists(tokenId)",  # Ensures the token exists
            ReturnValues="ALL_NEW"
        )
        
        return True
    except Exception as e:
        logging.error(e, exc_info=True)
        return False

def update_tokens(token_ids):

    try:
        for token_id in token_ids:
            response = table.update_item(
                Key={'tokenId': token_id["tokenId"]},
                UpdateExpression="SET giftStatus = :gift_status",
                ExpressionAttributeValues={':gift_status': "EMAIL_SEND"},
                ConditionExpression="attribute_exists(tokenId)",  # Ensures the token exists
                ReturnValues="ALL_NEW"
            )
        return True
    except Exception as e:
        logging.error(e, exc_info=True)
        return False
