import logging
from profile import *
from photo_shoot import *
from helpers import *
from image_validations import validate_images
from stripe_api import *
from photo_shoot_token import *
from config import *

def handler(event, context):
    logging.error(event)
    if "source" in event and event["source"] == "frontend_prewarmup":
        logging.error("Warming up")
        return None
    try:
        user_id = event["requestContext"]["username"]
        action =event["action"]

        # profile related endpoints
        if action == "createSingleProfile":
            profile_name = event["request"]["profileName"]
            profile_gender = event["request"]["profileGender"]
            profile_type = event["request"]["profileType"]
            if profile_gender not in ("MALE","FEMALE"):
                return {"message":"bad request", "statusCode":"400"}

            return create_profile(user_id,profile_name, profile_gender, profile_type)
            
        elif action == "preWarmUpLambda":
            return {"message":"successful","statusCode":200}

        elif action == "headShotCreateCheckoutSession":
            # Extract request parameters
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            user_email = event["request"]["userEmail"]
            return_url = event["request"]["returnUrl"]
            photo_shoot_data = get_photo_shoot(user_id,profile_id,photo_shoot_id)["photoShoots"][0]
            plan= photo_shoot_data["photoShootPlan"]
            if photo_shoot_data["isGiftMode"]:
                return {"message":"bad request","statusCode":400}

            plan_product_data = PLANS[plan]
            # Call utility function to create a checkout session
            client_secret = create_checkout_session(plan_product_data, user_email, return_url)
            return {"clientSecret": client_secret,"message":"successful","statusCode":200}

        elif action == "headShotGetSessionStatus":
            # Extract session ID from request
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            session_id = event["request"]["sessionId"]

            # Call utility function to get session status
            status = get_session_status(session_id)
            if status == "paid":
                update_photo_shoot(user_id, profile_id,photo_shoot_id,{"photoShootStatus":"PHOTOSHOOT_PAYMENT_DONE","isPaymentDone":True})
            else:
                update_photo_shoot(user_id, profile_id,photo_shoot_id,{"isPaymentDone":False})
            return {"status": status,"message":"successful","statusCode":200}

        elif action == "getAllSingleProfiles":
            return get_all_users_single_profiles(user_id)
        
        elif action == "deleteSingleProfile":
            profile_id = event["request"]["profileId"]
            return delete_single_profile(user_id, profile_id)

        elif action == "getSingleProfile":
            profile_id = event["request"]["profileId"]
            return get_single_profile(user_id, profile_id)

        # photoShoot related endpoints
        elif action == "createPhotoShoot":
            profile_id = event["request"]["profileId"]
            token = event["request"].get("photoShootToken",None)
            if token:
                output = get_token(token)
                if output["statusCode"] in (404,400,401):
                    return output
                
                if not update_token(token):
                    return {"statusCode": 400, "message": "bad request"}
                return create_photo_shoot(user_id, profile_id,photo_shoot_plan=output["data"]["photoShootPlan"],
                payment_method="PHOTOSHOOT_TOKEN",is_gift_mode=True,photo_shoot_token=token)

            return create_photo_shoot(user_id, profile_id)

        elif action == "deletePhotoShoot":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            return delete_photo_shoot(user_id, profile_id,photo_shoot_id)

        elif action == "getPhotoShoot":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            return get_photo_shoot(user_id, profile_id,photo_shoot_id)

        elif action == "getAllPhotoShoots":
            profile_id = event["request"]["profileId"]
            return get_all_profile_photo_shoots(user_id, profile_id)

        elif action == "updatePhotoShoot":
            profile_id = event["request"].pop("profileId")
            photo_shoot_id = event["request"].pop("photoShootId") 
            payment_check = get_photo_shoot(user_id,profile_id,photo_shoot_id)["photoShoots"][0].get("isPaymentDone",False)
            if payment_check:
                return {"message":"bad request","statusCode":400}

            if "photoShootStyle" in event["request"].keys():
                if not is_valid_list(event["request"]["photoShootStyle"]): 
                    return {"message":"bad request","statusCode":400}

            if "photoShootPlan" in event["request"].keys():
                if event["request"]["photoShootPlan"] not in ("STARTER","BASIC","PREMIUM"):
                    return {"message":"bad request","statusCode":400}

            event["request"]["photoShootStatus"] = "PHOTOSHOOT_PLAN_UPDATED"
            return update_photo_shoot(user_id, profile_id,photo_shoot_id,event["request"])

        elif action == "addPhotoShootTrainingImage":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            photo_shoot_images = event["request"].get("photoShootTrainingImage",[])
            return append_training_images(user_id, profile_id,photo_shoot_id,photo_shoot_images)

        elif action == "deletePhotoShootTrainingImage":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            photo_shoot_image_ids = event["request"].get("photoShootImageIds",[])
            return delete_training_images(user_id, profile_id,photo_shoot_id,photo_shoot_image_ids)

        elif action == "deletePhotoShootAllTrainingImages":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            return delete_all_training_images(user_id, profile_id,photo_shoot_id)


        elif action == "getLowResPhotoShoot":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            return get_low_res_photo_shoot(user_id, profile_id,photo_shoot_id)

        elif action == "getHighResAllPhotoShoot":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            return get_high_res_photo_shoot(user_id, profile_id,photo_shoot_id)

        elif action == "getHighResSinglePhotoShootImage":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            image_id = event["request"]["imageId"]
            return get_high_res_photo(user_id, profile_id,photo_shoot_id,image_id)

        elif action == "validateTrainingImages":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            image_ids = event["request"]["imageIds"]
            return validate_images(user_id, profile_id,photo_shoot_id,image_ids)

        elif action == "updateWeightedImage":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            image_ids = event["request"]["imageIds"]
            return update_training_image_flags(user_id, profile_id,photo_shoot_id,image_ids,True)
        elif action == "removeWeightedImage":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            return update_training_image_flags(user_id, profile_id,photo_shoot_id,image_ids,False)

        elif action == "startTrainingPhotoShoot":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            event["request"]["userId"]= user_id
            event["request"]["status"] = "START"
            event["request"]["token"] = event["requestContext"]["token"]
            photo_shoot_data = get_photo_shoot(user_id,profile_id,photo_shoot_id)["photoShoots"][0]
            if len(photo_shoot_data.get("photoShootTrainingImages",[]))<9:
                return {"message":"Training image not enough","statusCode":400}

            if not photo_shoot_data.get("isPaymentDone",False):
                return {"message":"payment is not done","statusCode":400}

            if photo_shoot_data.get("isTrainingComplete",False):
                return {"message":"training already done","statusCode":400}

            return start_training(event["request"])

        elif action == "getTrainingPhotoShootStatus":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            return get_status(user_id,profile_id,photo_shoot_id)


        elif action == "createPhotoShootToken":
            if not is_email_authentic(user_id):
                return {"message":"bad request","statusCode":400}
            gift_plan = event["request"]["giftPlan"]
            if gift_plan not in ("STARTER","BASIC","PREMIUM"):
                return {"message":"bad request","statusCode":400}
            return create_token(user_id,gift_plan)

        elif action == "verifyTrailMode":
            profile_id = event["request"]["profileId"]
            photo_shoot_id = event["request"]["photoShootId"]
            trail_mode = get_photo_shoot(user_id,profile_id,photo_shoot_id)["photoShoots"][0]["isGiftMode"]
            if not trail_mode:
                return {"message":"bad request","statusCode":400}
            return update_photo_shoot(user_id, profile_id,photo_shoot_id,{"photoShootStatus":"PHOTOSHOOT_PAYMENT_DONE","isPaymentDone":True})
            
        elif action == "headShotGiftCardCreation":
            gift_plan = event["request"]["giftPlan"]
            gift_recipients = event["request"]["giftRecipients"]
            sender_name = event["request"]["senderName"]
            sender_email = event["request"]["senderEmail"]
            gift_image = event["request"]["giftImage"]
            if gift_plan not in ("BASIC","STARTER","PREMIUM"):
                return {"statusCode": 400, "message": "bad request"}    
            
            return create_gift_token(gift_plan,gift_recipients,sender_name,sender_email,gift_image)

        elif action == "headShotGiftCardCheckoutSession":
            gift_token = event["request"]["giftToken"]
            return_url = event["request"]["returnUrl"]
            token_data = get_gift_tokens(gift_token)
            client_secret =  create_gift_checkout_session(token_data,return_url)
            return {"clientSecret": client_secret,"message":"successful","statusCode":200}

        elif action == "headShotGiftCardCheckoutSessionValidation":
            gift_token = event["request"]["giftToken"]
            session_id = event["request"]["sessionId"]
            status = get_session_status(session_id)
            if status == "paid":
                token_data = get_gift_tokens(gift_token)
                if update_tokens(token_data):
                    sending_email = send_sender_emails(token_data)
                    recipient_email = send_gift_emails(token_data)
                    logging.error(sending_email)
                    logging.error(recipient_email)
                    return {"message":"successful","statusCode":200}

            return {"statusCode": 400, "message": "bad request"} 
    except Exception as e:
        logging.error(e,exc_info=True)
        return {"statusCode": 400, "message": "bad request"}    


