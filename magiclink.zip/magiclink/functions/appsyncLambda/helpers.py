import os
import boto3
import logging
import json

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

BUCKET_NAME = os.environ["USER_MEDIA_STORAGE_BUCKET_NAME"]
user_table = dynamodb.Table(os.environ["DYNAMO_DB_TABLE_USERS"])

sf = boto3.client('stepfunctions')
pinpoint_client = boto3.client('pinpoint')

def is_valid_list(input_list):
    return all(item.isdigit() and 1 <= int(item) <= 24 for item in input_list if isinstance(item, str))

def is_email_authentic(user_id):
    try:
        response = user_table.get_item(
            Key={'userId': user_id}
        )
        
        if 'Item' in response:
            email =  response['Item']["email"]
            if email in ("talha.khawar@happr.ai","j@happr.ai"):
                return True
        else:
            return False
    except Exception as e:
        logging.error(f"Error retrieving user : {e}")
        return False

def start_training(input_dict):
    try:
        response = sf.start_execution(
            stateMachineArn = f'arn:aws:states:{os.environ["REGION"]}:{os.environ["ACCOUNT"]}:stateMachine:myprolook-{os.environ["DEPLOY_ENV"]}-app-stateMachine',
            input = json.dumps(input_dict)
        )
        return {"message":"successful","statusCode":200}
    except Exception as e: 
        logging.error(e,exc_info=True)
        return {"message":"bad request","statusCode":400}

def generate_presigned_url(s3_file_name: str) -> str:
    if s3_file_name == "" or s3_file_name == None:
        return s3_file_name
    signed_url = s3_client.generate_presigned_url(
        "get_object",
        Params={"Bucket": BUCKET_NAME, "Key": s3_file_name},
        ExpiresIn=900,
    )  # URL expires in 1 hour
    return signed_url


def send_sender_emails(token_data):
    application_id = os.environ["PINPOINT_APP_ID"]
    from_address = os.environ["TEMPLATE_0_FROM_ADDRESS"]
    email_template = os.environ["TEMPLATE_2_NAME"]
    sender_email = ""
    sender_name = ""
    recipient_name = ""

    for token in token_data:
        if token["isRedeemed"]:
            return {"message": "bad request", "statusCode": 400}
        
        recipient_name = recipient_name + "," + token["recipientName"]
        sender_email = token["senderEmail"]
        sender_name = token["senderName"]
        gift_image = token["giftImage"]

    response = pinpoint_client.send_messages(
        ApplicationId=application_id,
        MessageRequest={
            'Addresses': {
                sender_email: {
                    'ChannelType': 'EMAIL'
                }
            },
            'MessageConfiguration': {
                'EmailMessage': {
                    'FromAddress': from_address,
                    'Substitutions': {  # This is optional
                        'senderName': [sender_name],
                        'recipientName': [recipient_name],
                        'giftImage':[gift_image]
                    }
                }
            },
            'TemplateConfiguration': {
                'EmailTemplate': {
                    'Name': email_template,
                    'Version': 'latest'
                }
            }
        }
    )

    return {
        "message": response["MessageResponse"]["Result"][sender_email]["StatusMessage"],
        "statusCode": response["MessageResponse"]["Result"][sender_email]["StatusCode"],
        "deliveryStatus": response["MessageResponse"]["Result"][sender_email]["DeliveryStatus"]
    }

def send_gift_emails(token_data):
    application_id = os.environ["PINPOINT_APP_ID"]
    from_address = os.environ["TEMPLATE_0_FROM_ADDRESS"]
    email_template = os.environ["TEMPLATE_1_NAME"]

    for token in token_data:
        if token["isRedeemed"]:
            return {"message": "bad request", "statusCode": 400}

        recipient_name = token["recipientName"]
        sender_name = token["senderName"]
        address_to = token["recipientEmail"]
        personal_message = token["personalMessage"]
        gift_image = token["giftImage"]

        response = pinpoint_client.send_messages(
            ApplicationId=application_id,
            MessageRequest={
                'Addresses': {
                    address_to: {
                        'ChannelType': 'EMAIL'
                    }
                },
                'MessageConfiguration': {
                    'EmailMessage': {
                        'FromAddress': from_address,
                        'Substitutions': {  # This is optional
                            'recipientName': [recipient_name],
                            'senderName': [sender_name],
                            'giftImage':[gift_image],
                            'Domain': [f"{os.environ['HEAD_SHOT_DOMAIN']}/?photoShootToken={token['tokenId']}"]
                        }
                    }
                },
                'TemplateConfiguration': {
                    'EmailTemplate': {
                        'Name': email_template,
                        'Version': 'latest'
                    }
                }
            }
        )

    return {
        "message": response["MessageResponse"]["Result"][address_to]["StatusMessage"],
        "statusCode": response["MessageResponse"]["Result"][address_to]["StatusCode"],
        "deliveryStatus": response["MessageResponse"]["Result"][address_to]["DeliveryStatus"]
    }
