

import boto3
import uuid
import os
import logging
from photo_shoot import delete_photo_shoot
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ["DYNAMO_DB_TABLE_HEADSHOT_GENERATOR"])

def create_profile(user_id,profile_name, profile_gender, profile_type):
    
    # Generate a unique profileId
    profile_id = str(uuid.uuid4())
    
    item = {
        'userId':user_id,
        'itemId': f"PROFILE#{profile_id}",
        'profileName': profile_name,
        'profileGender': profile_gender,
        'profileType': profile_type
    }
    
    try:
        # Insert item into DynamoDB
        table.put_item(Item=item)
        return {"profileId":profile_id,"message":"profile created successfully","statusCode":200}
    except Exception as e:
        logging.error(e,exc_info=True)
        return {"message":"bad request","statusCode":400}

 

def delete_single_profile(user_id, profile_id):
    profile_item_id = f"PROFILE#{profile_id}"

    try:
        # Query for all photoshoots related to this profile
        response = table.query(
            KeyConditionExpression="userId = :user_id AND begins_with(itemId, :photoshoot_prefix)",
            ExpressionAttributeValues={
                ':user_id': user_id,
                ':photoshoot_prefix': f"PHOTOSHOOT#{profile_id}#"
            }
        )

        # Get the photoshoot details
        photo_shoots = response.get('Items', [])
        for photoshoot in photo_shoots:
            # Extract the photoshoot ID from the itemId
            photoshoot_id = photoshoot['itemId'].split("#")[-1]

            # Use the delete_photoshoot_by_id function
            delete_photo_shoot(user_id, profile_id, photoshoot_id)

        # Delete the profile itself
        table.delete_item(
            Key={
                'userId': user_id,
                'itemId': profile_item_id
            }
        )

        return {"message": "Profile and related photoshoots deleted successfully", "statusCode": 200}

    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "Failed to delete profile and photoshoots", "statusCode": 400}


def get_single_profile(user_id, profile_id):

    item_id = f"PROFILE#{profile_id}"
    try:
        # Fetch item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        profile = response.get('Item')
        if profile:
            profile.pop('userId', None)
            profile['profileId'] = profile.pop('itemId').split("#")[-1]
            return {"profiles": [profile], "statusCode": 200,"message":"successful"}
        else:
            return {"message": "Profile not found", "statusCode": 404}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}


def get_all_users_single_profiles(user_id):

    try:
        # Query to fetch all profiles for the given user_id
        response = table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key('userId').eq(user_id) & 
                                   boto3.dynamodb.conditions.Key('itemId').begins_with('PROFILE#')
        )
        profiles = response.get('Items', [])
        
        # Process each profile to remove userId and rename itemId to profileId
        for profile in profiles:
            profile.pop('userId', None)
            profile['profileId'] = profile.pop('itemId').split("#")[-1]
            
        return {"profiles": profiles, "statusCode": 200,"message":"successful"}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}
