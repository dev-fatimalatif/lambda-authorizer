import boto3
import uuid
import os
import logging
from helpers import *

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')
BUCKET_NAME = os.environ["USER_MEDIA_STORAGE_BUCKET_NAME"]
table = dynamodb.Table(os.environ["DYNAMO_DB_TABLE_HEADSHOT_GENERATOR"])


def delete_all_training_images(user_id, profile_id, photo_shoot_id):

    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    try:
        # Fetch the current photo shoot item
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        if not item or 'photoShootTrainingImages' not in item or not item['photoShootTrainingImages']:
            return {"message": "No training images found", "statusCode": 404}
        
        # Collect all S3 paths to delete
        s3_objects_to_delete = []
        payment_check = item.get("isPaymentDone",False)
        photo_shoot_new_status = "PHOTOSHOOT_CREATED"
        if payment_check:
            photo_shoot_new_status = "PHOTOSHOOT_PAYMENT_DONE"

        for img in item['photoShootTrainingImages']:
            s3_path = img.get('imagePath')
            if s3_path:
                s3_objects_to_delete.append({"Key": s3_path})
        
        # Delete all images from S3
        if s3_objects_to_delete:
            s3_client.delete_objects(
                Bucket=BUCKET_NAME,
                Delete={"Objects": s3_objects_to_delete}
            )
        
        # Set photo shootTrainingImages to an empty list in DynamoDB
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET photoShootTrainingImages = :empty_list, photoShootStatus = :new_status",
            ExpressionAttributeValues={
                ':empty_list': [],
                ':new_status':photo_shoot_new_status
            }
        )
        
        return {"message": "All images deleted successfully from DynamoDB and S3", "statusCode": 200}
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}


def get_status(user_id,profile_id,photo_shoot_id):
    photo_shoot_data = get_photo_shoot(user_id,profile_id,photo_shoot_id)["photoShoots"][0]
    status = photo_shoot_data["photoShootStatus"]
    
    return {"message":"successful","statusCode":"200","status":status,"profileId":profile_id,"photoShootId":photo_shoot_id}


def create_photo_shoot(user_id,profile_id,photo_shoot_plan="",payment_method="STRIPE",is_gift_mode=False,photo_shoot_token=""):
    
    # Generate a unique profileId
    photo_shoot_id = str(uuid.uuid4())
    
    item = {
        'userId':user_id,
        'itemId': f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}",
        'photoShootStatus': "PHOTOSHOOT_CREATED",
        'photoShootTrainingImages':[],
        'photoShootGeneratedImages':[],
        'photoShootPaymentMethod':payment_method,
        'isPaymentDone':False,
        'photoShootToken':photo_shoot_token,
        'photoShootPlan':photo_shoot_plan,
        'isGiftMode':is_gift_mode
    }
    
    try:
        # Insert item into DynamoDB
        table.put_item(Item=item)
        return {"photoShootId":photo_shoot_id,"profileId":profile_id,"message":"photo shoot created successfully","statusCode":200}
    except Exception as e:
        logging.error(e,exc_info=True)
        return {"message":"bad request","statusCode":400}

 
def delete_photo_shoot(user_id, profile_id,photo_shoot_id):
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    try:
        # Delete item from DynamoDB
        table.delete_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        if delete_all_training_images(user_id, profile_id,photo_shoot_id)["statusCode"] in (200,404):
            return {"message":"successful","statusCode":200}
        else:
            return {"message":"successful","statusCode":200}

    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}

def get_photo_shoot(user_id, profile_id,photo_shoot_id):

    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    try:
        # Fetch item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        photo_shoot = response.get('Item')
        if photo_shoot:
            photo_shoot.pop('userId', None)
            item_id = photo_shoot.pop("itemId").split("#")
            photo_shoot['profileId'] = item_id[1]
            photo_shoot['photoShootId'] = item_id[-1]
            training_images = photo_shoot.get("photoShootTrainingImages", [])
            for image in training_images:
                if "imagePath" in image:
                    image["url"] = generate_presigned_url(image["imagePath"])

            return {"photoShoots": [photo_shoot], "statusCode": 200,"message":"successful"}
        else:
            return {"message": "photo shoot not found", "statusCode": 404}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}


def get_all_profile_photo_shoots(user_id,profile_id):

    try:
        # Query to fetch all profiles for the given user_id
        response = table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key('userId').eq(user_id) & 
                                   boto3.dynamodb.conditions.Key('itemId').begins_with(f'PHOTOSHOOT#{profile_id}#')
        )
        photo_shoots = response.get('Items', [])
        
        # Process each profile to remove userId and rename itemId to profileId
        for photo_shoot in photo_shoots:
            photo_shoot.pop('userId', None)
            item_id = photo_shoot.pop("itemId").split("#")
            photo_shoot['profileId'] = item_id[1]
            photo_shoot['photoShootId'] = item_id[-1]
            training_images = photo_shoot.get("photoShootTrainingImages", [])
            for image in training_images:
                if "imagePath" in image:
                    image["url"] = generate_presigned_url(image["imagePath"])
        return {"photoShoots": photo_shoots, "statusCode": 200,"message":"successful"}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}


def update_photo_shoot(user_id, profile_id, photo_shoot_id, update_data):

    # Define the itemId based on the profile and photo shoot IDs
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    # Initialize the update expression and attribute values
    update_expression = []
    expression_attribute_values = {}
    
    # Add fields to the update expression dynamically based on update_data
    for key, value in update_data.items():
        if value is not None:  # Only include fields with non-None values
            update_expression.append(f"{key} = :{key}")
            expression_attribute_values[f":{key}"] = value
    
    # If no valid fields are provided, return a bad request response
    if not update_expression:
        return {"message": "No fields to update", "statusCode": 400}
    
    # Build the final update expression
    update_expression = "SET " + ", ".join(update_expression)
    
    try:
        # Update the item in DynamoDB
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values
        )
        return {
            "photoShootId": photo_shoot_id,
            "profileId": profile_id,
            "message": "Photo shoot updated successfully",
            "statusCode": 200
        }
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "Failed to update photo shoot", "statusCode": 400}





def append_training_images(user_id, profile_id, photo_shoot_id, photo_shoot_images):
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"

    # Generate a list of dictionaries with imageId and path for each image
    new_images = [{"imageId": str(uuid.uuid4()), "imagePath": path, "weighted": False} for path in photo_shoot_images]
    
    try:
        # Fetch the current photo shoot item to check payment status
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        
        if not item:
            return {"message": "Photo shoot not found", "statusCode": 404, "trainingImagesAdded": []}

        # Determine the new status based on the payment check
        is_payment_done = item.get("isPaymentDone", False)
        new_status = "PHOTOSHOOT_IMAGE_UPLOADED" if not is_payment_done else "PHOTOSHOOT_PAYMENT_DONE"

        # Append new images to the photoShootTrainingImages list
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET photoShootStatus = :new_status, photoShootTrainingImages = list_append(photoShootTrainingImages, :new_images)",
            ExpressionAttributeValues={
                ':new_images': new_images,
                ':new_status': new_status
            }
        )
        return {"message": "successful", "statusCode": 200, "trainingImagesAdded": new_images}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400, "trainingImagesAdded": []}


def append_generated_images(user_id, profile_id, photo_shoot_id, photo_shoot_images):
    # return the data aswell
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    # Generate a list of dictionaries with imageId and path for each image    
    try:
        # Append new images to the photoShootTrainingImages list
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET photoShootGeneratedImages = list_append(photoShootGeneratedImages, :new_images)",
            ExpressionAttributeValues={
                ':new_images': photo_shoot_images
            }
        )
        return {"message": "successful", "statusCode": 200}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}



def delete_training_images(user_id, profile_id, photo_shoot_id, photo_shoot_image_ids):

    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    try:
        # Fetch the current photo shoot item
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        payment_check = item.get("isPaymentDone",False)
        photo_shoot_new_status = "PHOTOSHOOT_CREATED"
        if payment_check:
            photo_shoot_new_status = "PHOTOSHOOT_PAYMENT_DONE"

        if not item or 'photoShootTrainingImages' not in item or not item['photoShootTrainingImages']:
            return {"message": "No training images found", "statusCode": 404}
        
        # Separate images to delete based on imageIds
        images_to_keep = []
        s3_objects_to_delete = []
        
        for img in item['photoShootTrainingImages']:
            if img['imageId'] in photo_shoot_image_ids:
                s3_path = img.get('imagePath')
                if s3_path:
                    s3_objects_to_delete.append({"Key": s3_path})
            else:
                images_to_keep.append(img)
        
        # Delete images from S3
        if s3_objects_to_delete:
            s3_client.delete_objects(
                Bucket=BUCKET_NAME,
                Delete={"Objects": s3_objects_to_delete}
            )
        
        # Update DynamoDB item with the filtered list of images
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET photoShootTrainingImages = :images_to_keep",
            ExpressionAttributeValues={
                ':images_to_keep': images_to_keep
            }
        )

        if len(images_to_keep) == 0:
            update_photo_shoot(user_id,profile_id,photo_shoot_id,{"photoShootStatus":photo_shoot_new_status})

        return {"message": "Images deleted successfully from DynamoDB and S3", "statusCode": 200}
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}

def update_training_image_flags(user_id, profile_id, photo_shoot_id, image_ids, flag_value):
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    try:
        # Step 1: Fetch the photo shoot item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        
        # Step 2: Check if the item exists and has training images
        if not item or 'photoShootTrainingImages' not in item or not item['photoShootTrainingImages']:
            return {"message": "No training images found", "statusCode": 404}
        
        training_images = item['photoShootTrainingImages']
        
        # Step 3: Update the flag for images with matching image IDs
        for img in training_images:
            if img.get('imageId') in image_ids:
                img['weighted'] = flag_value  # Update or set the boolean flag in each matched image dictionary
        
        # Step 4: Write the updated list back to DynamoDB
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET photoShootTrainingImages = :updated_images",
            ExpressionAttributeValues={
                ':updated_images': training_images
            }
        )
        
        return {
            "message": "Training images updated successfully",
            "statusCode": 200
        }
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}




def get_training_images_photo_shoot(user_id, profile_id, photo_shoot_id, image_ids):
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    try:
        # Step 1: Fetch the photo shoot item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        

        if not item or 'photoShootTrainingImages' not in item or not item['photoShootTrainingImages']:
            return {"message": "No training images found", "statusCode": 404}

        training_images = item['photoShootTrainingImages']
        # Step 3: Filter images by provided image IDs
        filtered_images = [
            {"imageId": img.get("imageId"), "imagePath": img.get("imagePath")}
            for img in training_images if img.get("imageId") in image_ids
        ]
        
        # Step 4: Return the filtered images
        return {
            "trainingImages": filtered_images,
            "message": "successful",
            "statusCode": 200
        }
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}


def get_low_res_photo_shoot(user_id, profile_id, photo_shoot_id):

    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    try:
        # Step 1: Fetch the photo shoot item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        
        if not item or 'photoShootGeneratedImages' not in item or not item['photoShootGeneratedImages']:
            return {"message": "No high-resolution images found", "statusCode": 404}
        
        low_res_images = item['photoShootGeneratedImages']
        
        # Step 3: Generate presigned URLs for each low-resolution image
        image_data = []
        for img in low_res_images:
            image_id = img.get('imageId')
            s3_path = img.get('lowResImagePath')
            
            if s3_path:
                
                try:
                    # Generate a presigned URL for the S3 object
                    presigned_url = generate_presigned_url(s3_path)
                    image_data.append({"imageId": image_id, "url": presigned_url})
                
                except Exception as e:
                    logging.error(e, exc_info=True)
                    return {"message": "bad request", "statusCode": 400}
        
        # Step 4: Update the photoshoot's status to 'viewed'
        is_downloaded = item.get('isDownloaded', False)
        if not is_downloaded:
            table.update_item(
                Key={
                    'userId': user_id,
                    'itemId': item_id
                },
                UpdateExpression="SET photoShootStatus = :new_status",
                ExpressionAttributeValues={
                    ':new_status': 'PHOTOSHOOT_IMAGE_VIEWED'
                }
            )
        
        # Step 5: Return the list of images with presigned URLs
        return {
            "lowResImages": image_data,
            "message": "successful",
            "statusCode": 200
        }
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}






def get_high_res_photo_shoot(user_id, profile_id, photo_shoot_id):

    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    try:
        # Step 1: Fetch the photo shoot item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        if not item or 'photoShootGeneratedImages' not in item or not item['photoShootGeneratedImages']:
            return {"message": "No high-resolution images found", "statusCode": 404}
        
        high_res_images = item['photoShootGeneratedImages']
        
        # Step 3: Generate presigned URLs for each high-resolution image and update the image status
        image_data = []
        for img in high_res_images:
            image_id = img.get('imageId')
            s3_path = img.get('highResImagePath')
            
            if s3_path:
                # Extract key from S3 path (assumes format "s3://bucket/key")
                
                try:
                    # Generate a presigned URL for the S3 object
                    presigned_url = generate_presigned_url(s3_path)
                    # Add image data with presigned URL and mark status as "downloaded"
                    image_data.append({"imageId": image_id, "url": presigned_url})
                    img['imageStatus'] = "IMAGE_DOWNLOADED"  # Update the status of each image to "downloaded"
                
                except Exception as e:
                    logging.error(e, exc_info=True)
                    return {"message": "bad request", "statusCode": 400}
        
        # Step 4: Update DynamoDB with the modified high-resolution image list and photo shoot status
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET isDownloaded=:download_status,photoShootGeneratedImages = :updated_images, photoShootStatus = :new_status",

            ExpressionAttributeValues={
                ':updated_images': high_res_images,
                ':new_status': 'PHOTOSHOOT_IMAGE_DOWNLOADED',
                ':download_status':True
            }
        )
        
        # Step 5: Return the list of high-res images with presigned URLs
        return {
            "highResImages": image_data,
            "message": "High-resolution images retrieved successfully",
            "statusCode": 200
        }
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}




def get_high_res_photo(user_id, profile_id, photo_shoot_id, image_id):
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    try:
        # Step 1: Fetch the photoshoot item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        item = response.get('Item')
        

        if not item or 'photoShootGeneratedImages' not in item or not item['photoShootGeneratedImages']:
            return {"message": "No high-resolution images found", "statusCode": 404}

        high_res_images = item['photoShootGeneratedImages']
        
        # Step 3: Find the image with the specified image_id
        selected_image = next((img for img in high_res_images if img.get('imageId') == image_id), None)
        
        if not selected_image:
            return {"message": "Image not found", "statusCode": 404}
        
        # Step 4: Generate presigned URL for the specified image
        s3_path = selected_image.get('highResImagePath')
        if s3_path:
            # Extract key from S3 path (assumes format "s3://bucket/key")
            
            try:
                # Generate a presigned URL for the S3 object
                presigned_url = generate_presigned_url(s3_path)
                # Update image status to "downloaded"
                selected_image['imageStatus'] = "IMAGE_DOWNLOADED"
            
            except ClientError as e:
                logging.error(e, exc_info=True)
                return {"message": "bad request", "statusCode": 400}
        
        # Step 5: Update DynamoDB with the modified image status
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET isDownloaded=:download_status,photoShootGeneratedImages = :updated_images,photoShootStatus = :new_status",
            ExpressionAttributeValues={
                ':updated_images': high_res_images,
                ':new_status':"PHOTOSHOOT_IMAGE_DOWNLOADED",
                ':download_status':True
            }
        )
        
        # Step 6: Return the presigned URL for the specific image
        return {
            "imageId": image_id,
            "url": presigned_url,
            "message": "High-resolution image retrieved successfully",
            "statusCode": 200
        }
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}

