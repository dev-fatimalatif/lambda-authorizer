import boto3
import numpy as np
import io
import os
import logging
from photo_shoot import *
from openai import OpenAI
from pydantic import BaseModel, Field
os.environ["OPENAI_API_KEY"]= os.environ["OPENAIAPIKEY"]

client = OpenAI()

class SingleValidation(BaseModel):
    image_id: str = Field(..., description="A unique identifier for the image. e.g (1,2,3...)")
    issue: str = Field(..., description='A concise description of the primary issue (e.g., "Low light", "Face obstructed", "Tilted angle")')
    score: int = Field(..., description="A number between 1 and 10, representing the image quality score.")

class ImageValidation(BaseModel):
  validationScore: list[SingleValidation]
  overallScore: int
  overallMessage: str

def openai_validation(request_data):
    completion = client.beta.chat.completions.parse(
        model="gpt-4o",
        response_format=ImageValidation,
        max_tokens=1500,
        messages=[  
            {
                "role": "system",
                "content": [
                    {"type": "text", "text": "Please validate the provided images with maximum refinement and precision, ensuring the following criteria are strictly adhered to. Provide feedback in a structured JSON format with scores, specific feedback for each image, and an overall recommendation.\nValidation Criteria:\n1. Lighting and Shadows: Ensure even, well-balanced lighting with minimal shadows or overexposed areas.\n2. Angle Consistency: Confirm images are taken from controlled, consistent angles (front, slight left, slight right) and avoid any extreme perspectives.\n3. Facial Expression: Validate neutral or slightly varied facial expressions across images.\n5. Obstructions: Verify there are no obstructions (e.g., hats, sunglasses) that obscure the face.\n6. Image Quality: Ensure clarity and sharpness, rejecting blurry or low-quality images.\n7. Background Consistency: Check for a neutral or consistent background to maintain focus on the subject."},
                ],
            },
            {
                "role": "user",
                "content": request_data,
            }
        ],
    )

    data = (completion.choices[0].message.parsed)
    data = json.loads(json.dumps(data, default=lambda o: o.__dict__, indent=4))
    return data

def validate_images(user_id, profile_id, photo_shoot_id, image_ids):
    try:
        photo_shoot_training_data = get_training_images_photo_shoot(user_id, profile_id, photo_shoot_id, image_ids)["trainingImages"]
        photo_shoot_data = get_photo_shoot(user_id, profile_id, photo_shoot_id)["photoShoots"][0]
        total_images = photo_shoot_data.get("photoShootTrainingImages", [])
        is_training_done = photo_shoot_data.get("isTrainingComplete", False)
        if is_training_done or len(photo_shoot_training_data)<9:
            return {"message": "unsuccessful", "statusCode": 400}

        request_data = [{"type": "text", "text": f"evaluate these {len(photo_shoot_training_data)} images"}]
        mapping_dictionary = {}
        response_images = []
        counter = 1
        for image_data in photo_shoot_training_data:
            image_path = image_data['imagePath']
            image_id = image_data['imageId']
            mapping_dictionary[str(counter)] = {"imagePath":image_path,"imageId":image_id}
            counter = counter+1
            url = generate_presigned_url(image_path)
            request_data.append({"type":"image_url","image_url":{"url":url}})
        if not request_data:
            return {"invalidImages": [], "message": "unsuccessful", "statusCode": 400}
        data = openai_validation(request_data)
        validation_score = data["validationScore"]
        overall_score = data["overallScore"]
        overall_message = data["overallMessage"]
        for image in validation_score:
                required = mapping_dictionary[image["image_id"]]
                response_images.append({
                    "imageId": required["imageId"],
                    "imagePath": required["imagePath"],
                    "reason": image["issue"],
                    "score": image["score"]
                })

        return {"responseImages": response_images, "message": "successful","statusCode": 200,"overallScore": overall_score,"overallMessage":overall_message}
    
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "unsuccessful", "statusCode": 400}

