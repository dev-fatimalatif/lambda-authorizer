PLANS = {
    "BASIC":
        {
            "price_data": {
                "currency": "usd",
                "product_data": {
                    "name": "basic Plan",
                    "description": "This plan includes basic features for beginners.",
                },
                "unit_amount": 6999,  # $49 in cents
            },
            "quantity": 1,
        },
    "STARTER":
        {
            "price_data": {
                "currency": "usd",
                "product_data": {
                    "name": "starter Plan",
                    "description": "This plan includes intermediate features for growing needs.",
                },
                "unit_amount": 9999,  # $59 in cents
            },
            "quantity": 1,
        },
    "PREMIUM":
        {
            "price_data": {
                "currency": "usd",
                "product_data": {
                    "name": "Premium Plan",
                    "description": "This plan includes advanced features for professionals.",
                },
                "unit_amount": 12999,  # $69 in cents
            },
            "quantity": 1,
        }
}