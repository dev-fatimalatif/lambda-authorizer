import fal_client
from helpers import *
from config import *
import logging
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed

def create_request(data, user_name):
    try:
        handler = fal_client.submit(
            "fal-ai/flux-lora-fast-training",
            arguments={
                "images_data_url": data,
                "create_masks": True,
                "steps": 2000,
                "trigger_word": user_name,
                "is_style": False    
            }
        )
        return handler.request_id
    except Exception as e:
        logging.error("Error creating request", exc_info=True)
        raise RuntimeError(f"Failed to create training request: {e}")

def start_training(token,user_id, profile_id, photo_shoot_id):
    try:
        user_gender =  get_single_profile(user_id,profile_id)["profileGender"]
        if user_gender == "FEMALE":
            user_name = "Jane"
        else: 
            user_name = "John"
    except Exception as e:
        logging.error(e,exc_info=True)
        return {"payload":{"requestId":"","token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_TRAINING_ERROR","error_message":str(e)}}

    temp_zip_path = f'/tmp/{user_name}_photos.zip'
    try:
        zip_buffer = zip_images_from_s3(f"{user_id}/headshot-generator/{profile_id}/{photo_shoot_id}/training-images",user_name)
        
        # Define the temp file path
        
        # Save the zip buffer to the temp file
        with open(temp_zip_path, 'wb') as f:
            f.write(zip_buffer.read())
        
        # Upload the zip file via API
        response = fal_client.upload_file(temp_zip_path)
        # Create request and update photo shoot
        request_id = create_request(response,user_name)
        output = update_photo_shoot(user_id, profile_id, photo_shoot_id, {"requestId":request_id,"photoShootStatus":"PHOTOSHOOT_TRAINING_STARTED"})
        notify_progress_update(token,profile_id,photo_shoot_id)
        return {"payload":{"token":token,"requestId":request_id,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_TRAINING_STARTED"}}
    except Exception as e: 
        logging.error(e,exc_info=True)
        output = update_photo_shoot(user_id, profile_id, photo_shoot_id, {"requestId":"","photoShootStatus":"PHOTOSHOOT_TRAINING_ERROR"})
        notify_progress_update(token,profile_id,photo_shoot_id)
        return {"payload":{"requestId":"","token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_TRAINING_ERROR","error_message":str(e)}}
    finally:
        # Ensure the temp file is deleted
        if os.path.exists(temp_zip_path):
            os.remove(temp_zip_path)
 

def generate_image_batch(prompt, weights, batch_size):
    """Helper function to generate a batch of images."""
    try:
        result = fal_client.subscribe(
            "fal-ai/flux-lora",
            arguments={
                "prompt": prompt,
                "loras": [{
                    "path": weights,
                    "scale": 1
                }],
                "output_format": "jpeg",
                "num_images": batch_size,
                "guidance_scale": 3.5,
                "image_size": "square_hd"
            },
        )
        return [image["url"] for image in result["images"]]
    except Exception as e:
        logging.error(f"Error generating images for prompt '{prompt}': {e}", exc_info=True)
        return []  # Return an empty list in case of failure

def get_inference(weights, style_prompts, total_images):
    try:
        # Calculate max images per style and distribute remainder
        num_styles = len(style_prompts)
        images_per_style = total_images // num_styles
        extra_images = total_images % num_styles

        # Prepare tasks for the executor
        tasks = []
        for i, prompt in enumerate(style_prompts):
            images_for_this_prompt = images_per_style + (1 if i < extra_images else 0)
            while images_for_this_prompt > 0:
                batch_size = min(4, images_for_this_prompt)
                tasks.append((prompt, weights, batch_size))
                images_for_this_prompt -= batch_size

        # Use ThreadPoolExecutor for parallel processing
        image_urls_for_prompt = []
        with ThreadPoolExecutor(max_workers=min(total_images, len(tasks))) as executor:
            future_to_task = {executor.submit(generate_image_batch, *task): task for task in tasks}
            for future in as_completed(future_to_task):
                image_urls_for_prompt.extend(future.result())

        return image_urls_for_prompt
    except Exception as e:
        logging.error(e, exc_info=True)
        raise RuntimeError(f"Failed to generate inference images: {e}")


def get_status(token,user_id,profile_id,photo_shoot_id,request_id):

    try:
        status = fal_client.status("fal-ai/flux-lora-fast-training", request_id, with_logs=False)
    except Exception as e:
        return {"payload":{"requestId":request_id,"token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_TRAINING_ERROR","error_message":str(e)}}

    request_status = "PHOTOSHOOT_TRAINING_INPROGRESS"
    if isinstance(status,fal_client.InProgress):
        update_photo_shoot(user_id,profile_id,photo_shoot_id,{"photoShootStatus":"PHOTOSHOOT_TRAINING_INPROGRESS"})
        request_status = "PHOTOSHOOT_TRAINING_INPROGRESS"
    elif isinstance(status,fal_client.Completed):
        update_photo_shoot(user_id,profile_id,photo_shoot_id,{"photoShootStatus":"PHOTOSHOOT_TRAINING_COMPLETED"})
        request_status = "PHOTOSHOOT_TRAINING_COMPLETED"

    notify_progress_update(token,profile_id,photo_shoot_id)
    return {"payload":{"requestId":request_id,"token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":request_status}}


def get_results(token,user_id,profile_id,photo_shoot_id,request_id):
    try:
        user_data = get_single_profile(user_id,profile_id)
        profile_gender =  user_data["profileGender"]
        if profile_gender == "FEMALE":
            user_name = "Jane"
            PROMPTS = PROMPTS_FEMALE
        else:
            user_name = "John"
            PROMPTS = PROMPTS_MALE
        email = get_user_email(user_id)
    except Exception as e:
        logging.error(e,exc_info=True)
        return {"payload":{"requestId":"","token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_TRAINING_ERROR","error_message":str(e)}}

    photo_shoot_data = get_photo_shoot(user_id,profile_id,photo_shoot_id)["photoShoots"][0]
    styles = (photo_shoot_data["photoShootStyle"])
    total_images = PLANS_MAP[photo_shoot_data["photoShootPlan"].upper()]["total_images"]
    style_prompts = [PROMPTS[int(style)-1] for style in styles]
    try:
        result = fal_client.result("fal-ai/flux-lora-fast-training", request_id) 
        path = result["diffusers_lora_file"]["url"]
        update_photo_shoot(user_id,profile_id,photo_shoot_id,{"weightURL":path})
    except Exception as e:
        logging.error(e)
        update_photo_shoot(user_id,profile_id,photo_shoot_id,{"photoShootStatus":"PHOTOSHOOT_TRAINING_ERROR"})
        notify_progress_update(token,profile_id,photo_shoot_id)
        return {"payload":{"requestId":request_id,"token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_TRAINING_ERROR","error_message":str(e)}}
    try:
        result = get_inference(path,style_prompts,total_images)
        all_images = []
        for image_url in result:
            data = {}
            data["imageId"] = str(uuid.uuid4())
            output_image = buffer_image_from_url(image_url)
            s3_key_high = f"{user_id}/headshot-generator/{profile_id}/{photo_shoot_id}/high-res-generated-images/{str(uuid.uuid4())}.jpg"
            save_image_to_s3(output_image,s3_key_high)
            s3_key_low = f"{user_id}/headshot-generator/{profile_id}/{photo_shoot_id}/low-res-generated-images/{str(uuid.uuid4())}.jpg"
            watermarked_image = add_watermark_to_image(output_image)
            if watermarked_image:
                save_image_to_s3(watermarked_image,s3_key_low)
            data["lowResImagePath"] = s3_key_low
            data["highResImagePath"] = s3_key_high
            data["imageStatus"] = "GENERATED"
            all_images.append(data)
        append_generated_images(user_id, profile_id, photo_shoot_id,all_images)
        update_photo_shoot(user_id,profile_id,photo_shoot_id,{"photoShootStatus":"PHOTOSHOOT_IMAGE_GENERATED","isTrainingComplete":True})
        notify_progress_update(token,profile_id,photo_shoot_id)
        result = completion_email(email,user_data["profileName"],profile_id,photo_shoot_id)
        logging.error(result)
        return {"payload":{"requestId":request_id,"token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_IMAGE_GENERATED"}}
    except Exception as e:
        logging.error(e,exc_info=True)
        update_photo_shoot(user_id,profile_id,photo_shoot_id,{"photoShootStatus":"PHOTOSHOOT_TRAINING_ERROR"})
        notify_progress_update(token,profile_id,photo_shoot_id)
        return {"payload":{"requestId":request_id,"token":token,"profileId":profile_id,"photoShootId":photo_shoot_id,"userId":user_id,"status":"PHOTOSHOOT_TRAINING_ERROR","error_message":str(e)}}
