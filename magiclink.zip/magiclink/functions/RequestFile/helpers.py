import boto3
import os
import zipfile
from PIL import Image
import io
import random
import requests
import logging
from PIL import ImageDraw, ImageFont

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
pinpoint_client = boto3.client('pinpoint')

table = dynamodb.Table(os.environ["DYNAMO_DB_TABLE_HEADSHOT_GENERATOR"])
BUCKET_NAME = os.environ["USER_MEDIA_STORAGE_BUCKET_NAME"]
user_table = dynamodb.Table(os.environ["DYNAMO_DB_TABLE_USERS"])


def get_user_email(user_id):
    try:
        response = user_table.get_item(
            Key={'userId': user_id}
        )
        
        if 'Item' in response:
            email =  response['Item']["email"]
            return email
        else:
            logging.info(f"No user found with user_id")
            return ""
    except Exception as e:
        logging.error(f"Error retrieving user : {e}")
        return ""


def completion_email(address_to,first_name,profile_id,photo_shoot_id):

	application_id = os.environ["PINPOINT_APP_ID"] 
	from_address = os.environ["TEMPLATE_0_FROM_ADDRESS"]
	# substitution1 = 'color' # Message substitution variable name
	# substitution1_value = 'orange' # Message substitution variable value
	email_template = os.environ["TEMPLATE_0_NAME"] # The email template name

	response = pinpoint_client.send_messages(
		ApplicationId = application_id,
		MessageRequest = {
			'Addresses': {
			address_to: {
				 'ChannelType': 'EMAIL'
			}},
			'MessageConfiguration': {
				'EmailMessage': {
			'FromAddress': from_address,
			'Substitutions': {		# This is optional
				'FirstName': [first_name],
                'PhotoshootId': [photo_shoot_id],
                'ProfileId': [profile_id],
                'Domain':[os.environ["HEAD_SHOT_DOMAIN"]]
			}
		}},
		'TemplateConfiguration': {
			'EmailTemplate': {
				'Name': email_template,
				'Version': 'latest'
			}
		}
		}
	)
	return {
        "message":response["MessageResponse"]["Result"][address_to]["StatusMessage"],
        "statusCode":response["MessageResponse"]["Result"][address_to]["StatusCode"],
        "deliveryStatus":response["MessageResponse"]["Result"][address_to]["DeliveryStatus"]
    }

def notify_progress_update(token,profile_id,photo_shoot_id):
    URL = f"https://{os.environ['API_DOMAIN']}/graphql"
    try:
        # Define the GraphQL mutation
        mutation = """
        mutation GetTrainingPhotoShootStatus($photo_shoot_id: String!,$profile_id: String!) {
            getTrainingPhotoShootStatus(request: {photoShootId: $photo_shoot_id,profileId: $profile_id}) {
                message
                statusCode
                status
                profileId
                photoShootId
            }
        }
        """
        
        # Request body with variables
        request_body = {
            "query": mutation,
            "variables": {
                "photo_shoot_id": photo_shoot_id,
                "profile_id":profile_id
            }
        }
        
        # Set headers for the request
        headers = {
            "Authorization": token,  # Assuming this is the API Key or token
            "Content-Type": "application/json"
        }
        
        # Make the POST request
        response = requests.post(URL, json=request_body, headers=headers)
        # Check the response and return results
        if response.status_code == 200:
            return True
        logging.error(response.status_code)
        return False
    except Exception as e:
        logging.error(e,exc_info=True)
        return False

def add_watermark_to_image(img, watermark_text="OHHYESSS"):
    try:
        # Convert image to RGBA (support transparency)
        original = img.convert("RGBA")
        width, height = original.size
        watermark = Image.new("RGBA", (width, height), (255, 255, 255, 0))
        font_size = max(int(width / 10), 36)
        font = ImageFont.truetype(f"{os.getcwd()}/arial.ttf", font_size)

        draw = ImageDraw.Draw(watermark)
        # Set a semi-transparent white color for the watermark
        text_color = (255, 255, 255, 100)  # 50% transparency

        # Calculate the diagonal text dimensions
        text_bbox = draw.textbbox((0, 0), watermark_text, font=font)
        text_width, text_height = text_bbox[2] - text_bbox[0], text_bbox[3] - text_bbox[1]

        # Create a larger canvas to accommodate the diagonal text
        diagonal_canvas_size = int((width**2 + height**2)**0.5)
        text_layer = Image.new("RGBA", (diagonal_canvas_size, diagonal_canvas_size), (255, 255, 255, 0))
        text_draw = ImageDraw.Draw(text_layer)

        # Calculate positions for text placement
        for x in range(0, diagonal_canvas_size, int(1.5 * text_width)):
            for y in range(0, diagonal_canvas_size, int(1.5 * text_height)):
                text_draw.text((x, y), watermark_text, font=font, fill=text_color)

        # Rotate the text layer to make it diagonal
        text_layer = text_layer.rotate(45, expand=True)

        # Crop to the original image size
        watermark.paste(text_layer, (-int((text_layer.width - width) / 2), -int((text_layer.height - height) / 2)), text_layer)

        # Apply the watermark to the image
        watermarked = Image.alpha_composite(original, watermark)

        # Save the output image
        return watermarked.convert("RGB")
    except Exception as e:
        logging.error(f"Error adding watermark: {e}", exc_info=True)
        return None

def save_image_to_s3(image, s3_key):
    try:
        # Create a BytesIO buffer to hold the image data
        img_buffer = io.BytesIO()
        
        # Save the PIL image to the buffer in JPG format (you can change format if needed)
        image.save(img_buffer, format="JPEG")
        
        # Move the cursor to the beginning of the buffer before uploading
        img_buffer.seek(0)
        
        # Define the S3 key (path within the bucket)

        # Upload the image buffer to S3
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=s3_key,
            Body=img_buffer,
            ContentType="image/jpeg"  # Adjust if saving in a different format
        )
        
        return True

    except Exception as e:
        logging.error(e,exc_info=True)
        return False

def update_photo_shoot(user_id, profile_id, photo_shoot_id, update_data):

    # Define the itemId based on the profile and photo shoot IDs
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    # Initialize the update expression and attribute values
    update_expression = []
    expression_attribute_values = {}
    
    # Add fields to the update expression dynamically based on update_data
    for key, value in update_data.items():
        if value is not None:  # Only include fields with non-None values
            update_expression.append(f"{key} = :{key}")
            expression_attribute_values[f":{key}"] = value
    
    # If no valid fields are provided, return a bad request response
    if not update_expression:
        return {"message": "No fields to update", "statusCode": 400}
    
    # Build the final update expression
    update_expression = "SET " + ", ".join(update_expression)
    
    try:
        # Update the item in DynamoDB
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values
        )
        return True
    except Exception as e:
        logging.error(e, exc_info=True)
        return False



def get_single_profile(user_id, profile_id):

    item_id = f"PROFILE#{profile_id}"
    try:
        # Fetch item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        profile = response.get('Item')
        if profile:
            profile.pop('userId', None)
            profile['profileId'] = profile.pop('itemId').split("#")[-1]
            return profile
        else:
            return {}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {}

def convert_to_jpg(image_data):
    # Open the image using PIL
    img = Image.open(io.BytesIO(image_data))
    
    # If the image is not in RGB mode (which is standard for JPG), convert it
    if img.mode != 'RGB':
        img = img.convert('RGB')

    # Save the image to a BytesIO object in .jpg format
    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format='JPEG')
    img_byte_arr.seek(0)
    
    return img_byte_arr

def zip_images_from_s3(s3_folder_prefix, user_name):

    response = s3_client.list_objects_v2(
        Bucket=BUCKET_NAME,
        Prefix=s3_folder_prefix
    )
    
    # Create a BytesIO buffer to hold the zip file in memory
    zip_buffer = io.BytesIO()

    # Create a zip file in memory
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Iterate over the images in the S3 folder
        for obj in response.get('Contents', []):
            file_name = obj['Key']
            if not file_name.lower().endswith(('.png', '.jpg', '.jpeg')):  # Ensure only images are processed
                continue

            # Download the image from S3 into memory
            image_data = s3_client.get_object(Bucket=BUCKET_NAME, Key=file_name)['Body'].read()
            
            # Convert the image to JPG if it's not already in JPG format
            jpg_image_data = convert_to_jpg(image_data)
            
            # Generate a new file name
            random_number = random.randint(1000, 9999)
            new_file_name = f"a_photo_of_{user_name}_{random_number}.jpg"
            
            # Add the converted image to the zip file with the new name
            zipf.writestr(new_file_name, jpg_image_data.read())
    
    # Move the buffer's cursor to the beginning before returning
    zip_buffer.seek(0)

    return zip_buffer

def buffer_image_from_url(image_url):
    try:
        # Download the image from the URL
        response = requests.get(image_url)
        response.raise_for_status()  # Check if the request was successful

        # Convert the content to a BytesIO buffer
        image_data = io.BytesIO(response.content)

        # Open the image using PIL
        image = Image.open(image_data)

        return image
    except Exception as e:
        logging.error(e,exc_info=True)
        return None

def get_photo_shoot(user_id, profile_id,photo_shoot_id):

    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    try:
        # Fetch item from DynamoDB
        response = table.get_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            }
        )
        photo_shoot = response.get('Item')
        if photo_shoot:
            photo_shoot.pop('userId', None)
            item_id = photo_shoot.pop("itemId").split("#")
            photo_shoot['profileId'] = item_id[1]
            photo_shoot['photoShootId'] = item_id[-1]
            return {"photoShoots": [photo_shoot], "statusCode": 200,"message":"successful"}
        else:
            return {"message": "photo shoot not found", "statusCode": 404}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}


def append_generated_images(user_id, profile_id, photo_shoot_id, photo_shoot_images):
    # return the data aswell
    item_id = f"PHOTOSHOOT#{profile_id}#{photo_shoot_id}"
    
    # Generate a list of dictionaries with imageId and path for each image    
    try:
        # Append new images to the photoShootTrainingImages list
        table.update_item(
            Key={
                'userId': user_id,
                'itemId': item_id
            },
            UpdateExpression="SET photoShootGeneratedImages = list_append(photoShootGeneratedImages, :new_images)",
            ExpressionAttributeValues={
                ':new_images': photo_shoot_images
            }
        )
        return {"message": "successful", "statusCode": 200}
    except Exception as e:
        logging.error(e, exc_info=True)
        return {"message": "bad request", "statusCode": 400}
