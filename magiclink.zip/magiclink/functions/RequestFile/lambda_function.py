
from fal_apis import *
import logging 
def handler(event, context):
    logging.error(event)
    try:
        data = event["payload"]
    except: 
        data = event
    if data["status"] == "START":
        return start_training(data["token"],data["userId"],data["profileId"],data["photoShootId"])
    elif data["status"] == "PHOTOSHOOT_TRAINING_STARTED" or data["status"] == "PHOTOSHOOT_TRAINING_INPROGRESS":
        return get_status(data["token"],data["userId"],data["profileId"],data["photoShootId"],data["requestId"])
    elif data["status"] == "PHOTOSHOOT_TRAINING_COMPLETED":
        return get_results(data["token"],data["userId"],data["profileId"],data["photoShootId"],data["requestId"])
    