import json
def handler(event, context):
    # Your Lambda logic here
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
