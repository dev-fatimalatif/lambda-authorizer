import json

def lambda_handler(event, context):
    if event['request'].get('userNotFound', False):
        event['response']['issueTokens'] = False
        event['response']['failAuthentication'] = True
        return event

    if not event['request'].get('session', []):
        # Issue a new challenge
        event['response']['issueTokens'] = False
        event['response']['failAuthentication'] = False
        event['response']['challengeName'] = 'CUSTOM_CHALLENGE'
    else:
        # Get the last attempt in the session
        last_attempt = event['request']['session'][-1]
        if last_attempt.get('challengeResult', False):
            # User provided the correct answer
            event['response']['issueTokens'] = True
            event['response']['failAuthentication'] = False
        else:
            # User provided the wrong answer
            event['response']['issueTokens'] = False
            event['response']['failAuthentication'] = True

    return event
